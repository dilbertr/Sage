import codecs
import sys
import os
import time




#-------LEFTOVER SAGE CODE----------
#def all_primitive_roots(n):
#	roots=[]
#	g=primitive_root(n)
#	for i in range(n):
#			roots.append(g^i%n)
#	roots.sort()
#	return roots
#def dlog(g,h,n):
#	#uses baby step giant step algorithm
#	G=Integers(n)
#	BabySteps={}
#	for i in range(floor(sqrt(n))):
#		BabySteps[G(g^i)]=i
#	for i in range(n):
#		if G(h*g^(-i*floor(sqrt(n)))) in BabySteps.keys():
#			value=G(h*g^(-i*floor(sqrt(n))))
#			return G((BabySteps[value]+i*floor(sqrt(n))))
#-----------------------------------



#RSA
def rsa_private_key_known(p,q,e):
	#G=Integers((p-1)*(q-1))
	#return G(e^(-1))
	return pow(e,-1,(p-1)*(q-1))
def rsa_public_key(p,q,e):
	return [p*q,e]
def rsa_encrypt(key,m):
	#return m^key[1]%key[0]
	return pow(m,key[1],key[0])
def rsa_decrypt(public,private,c):
	return pow(c,private,public[0])
def encode(s): #integer to unicode
	hecks=s.encode().hex()
	return int(hecks,16)
def decode(n): #unicode to integer
	hecks=hex(n) #couldn't use the name hex
	hecks=hecks[2:]
	for i in range(8):
		if len(hecks)%8 != 0:
			hecks=str("0")+str(hecks)
	raw=bytes.fromhex(hecks)
	return raw.decode()
def encrypt_file(source,destination,key):
	m=codecs.open(source,"r",encoding="utf-8",errors="ignore") #message
	c=open(destination,"w") #ciphertext
	block=''
	encrypted_block=''
	blocklength=32 #arbitrary, bigger blocklength = smaller file size
	written_block="" #block written to ciphertext
	while True:
		block=""
		block = m.read(blocklength)
		if block=="":
			break
		encrypted_block=""
		encrypted_block=hex(rsa_encrypt(key,encode(block))) #encode as hex
		written_block="\n"
		written_block=written_block+encrypted_block
		c.write(written_block)
	c.close()
	m.close()
def decrypt_file(source,destination,public,private):
	c=codecs.open(source,"r",errors="ignore") #ciphertext
	m=open(destination,"w") #message
	block=''
	char='' #current character
	decrypted_block=""
	done=False #have all characters been read
	while True:
		block=""
		while True:
			char=c.read(1)
			if char=="\n":
				break #block is complete
			if char=="":
				done=True #file is complete
				break
			block = block + char
		if block != "": #encrypted file starts with \n, so the 1st block is empty
			decrypted_block=decode(rsa_decrypt(public,private,int(block,0)))
			m.write(decrypted_block)
		if done==True:
			break
	m.close()
	c.close()

#usage is rsa [operation] [source] [public key (optional)]

keypaths=open("/Users/lorenzo/Sage/Cryptography/keypaths.dat","r").readlines()
#change for your installation
for i in [0,1]:
	keypaths[i]=keypaths[i][0:-1] #get rid of the \n
publicpath=keypaths[0]
if len(sys.argv)==4: #if a 3rd argument is provided, which would be the path for a seperate public key
	publicpath=sys.argv[3]
privatepath=keypaths[1]
source=sys.argv[2] #source file path
operation=sys.argv[1] #encryption or decryption

#reading the public key
public=open(publicpath,"r").read()
public=public.split(",")
for i in [0,1]:
	public[i]=int(public[i])


if operation=="encrypt":
	#start a timer
	start=time.time()
	#add the extension to our destination file
	destination=source+".encrypt"
	#encode the file (this algorithm can only encrypt ASCII)
	os.system("uuencode "+source+" "+source+" > "+source+".uue")
	encrypt_file(source+".uue",destination,public) #encrypt the encoded version
	os.system("rm "+source+".uue") #remove the encoded version
	print("Time: "+str(time.time()-start)+" seconds")
if operation=="decrypt":
	if source[-8:]!=".encrypt":
		print("Aborted: wrong file extension")
	destination=source[0:-8] #remove the .encrypt extension
	start=time.time()
	private=int(open(privatepath).read()) #read the private key
	decrypt_file(source,destination+".uue",public,private)

	#fine the path and filename, to move the decrypted file
	path=destination.split("/")
	filename=path[-1]
	path.pop() #remove the filename
	path="/".join(path)

	os.system("uudecode "+destination+".uue") #decode
	os.system("mv "+filename+" "+path) #move the decrypted file
	os.system("rm "+destination+".uue") #remove the coded file
	print("Time: "+str(time.time()-start)+" seconds")

